a=int(input('Enter a :'))
b=int(input('Enter b :'))
a=a^b
b=a^b
a=a^b
print('a = %d'%a)
print('b = %d'%b)
