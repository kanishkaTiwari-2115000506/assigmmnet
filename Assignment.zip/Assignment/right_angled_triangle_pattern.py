i=1
while i<=1_0:
    print(i * '*')
    i=i+1
