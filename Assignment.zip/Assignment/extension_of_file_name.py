name=input('Enter the file name : ')
breaks=name.split(".")
print("The extension of the file is : "+breaks[-1])
