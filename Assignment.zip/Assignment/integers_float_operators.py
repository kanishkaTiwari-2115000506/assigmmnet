print(3+2)#addition
print(3-2)#subtraction
print(3/2)#division
print(3*2)#multiplication
print(3//2)#floor division
print(3**2)#power
print(3%2)#remainder
print(abs(-3))#absolute value function
print(round(3.75))#round off
print(round(3.75,1))#round off upto any place after decimal
num1=1
num2=2
print(num1==num2)#comparison equale to
print(num1!=num2)#comparison not equale to
print(num1<num2)#comparison less than
print(num1>num2)#comparison more than
        #Typecasting in python
num_1 = '100'
num_2 = '200'
num_1 = int(num_1)
num_2 = int(num_2)
print(num_1 + num_2)
