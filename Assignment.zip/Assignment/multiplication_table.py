i = 1
num = int(input("Enter any number  : "))
while i <= 10:
    print(num," * ",i," = ", num * i)
    i = i+1
