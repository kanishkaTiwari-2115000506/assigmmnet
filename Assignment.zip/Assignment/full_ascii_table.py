for i in range(0,256,1):
    print('ASCII OF',chr(i),'   -->     ',i,)
