n = int(input('Enter till where you want to print natural numbers :'))
for i in range(1,n+1,1):
    print(i)
