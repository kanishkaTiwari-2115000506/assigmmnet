import math
p=int(input('Enter the perpendicular :'))
b=int(input('Enter the base :'))
h=math.sqrt((p*p)+(b*b))
print('The hypotenous is :%d'%h)
