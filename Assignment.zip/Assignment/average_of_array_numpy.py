import numpy as np

a = np.array([4, 5, 3, 7]).reshape(2,2)
print('input\n',a)

b = np.average(a)
print('average\n',b)
