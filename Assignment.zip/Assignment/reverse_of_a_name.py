first=input('Enter your 1st name : ')
second=input('Enter your 2nd name : ')
print(second +' '+ first)
