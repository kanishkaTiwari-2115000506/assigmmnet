import numpy as np

a = np.array([4, 5, 3, 7])
print('input\n',a)

b = np.sum(a)
print('sum\n',b)
